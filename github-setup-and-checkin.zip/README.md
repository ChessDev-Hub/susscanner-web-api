# Setup-And-CheckIn.ps1

One-shot PowerShell helper to initialize Git, create/link a GitHub repo in your org, push code, create labels, (optionally) apply branch protection, and open a PR.

## Requirements
- **Git**
- **GitHub CLI** (`gh`) authenticated: `gh auth login`

## Typical usages

### 1) Create repo (public), push main, and apply branch protection (require CI)
```powershell
.\Setup-And-CheckIn.ps1 `
  -Org "ChessDev-Hub" `
  -Repo "sus-scanner" `
  -Description "SusScanner React + Tailwind frontend" `
  -InitGit `
  -CreateRepo `
  -CommitMessage "chore: seed project" `
  -ApplyBranchProtection `
  -RequireCI
```

### 2) Open a PR instead of pushing to protected main
```powershell
.\Setup-And-CheckIn.ps1 `
  -Org "ChessDev-Hub" `
  -Repo "sus-scanner" `
  -InitGit `
  -CommitMessage "feat: add anonymized forum table + reasons" `
  -OpenPR `
  -Labels "docs","needs-review" `
  -PrTitle "Docs: anonymized forum export" `
  -PrBody "Adds REMOVED-username export for forum sharing."
```

### 3) Private repo and reviewers
```powershell
.\Setup-And-CheckIn.ps1 `
  -Org "ChessDev-Hub" `
  -Repo "sus-scanner-api" `
  -Private `
  -InitGit `
  -CreateRepo `
  -CommitMessage "api: initial FastAPI scaffold" `
  -OpenPR `
  -Reviewers "ChessDev-Hub/dev1","ChessDev-Hub/dev2"
```

## Notes
- Branch protection uses GitHub API. If you pass `-RequireCI`, it sets `"CI"` as a required status check (match your workflow job name).
- Labels are created idempotently.
- If the remote already exists, it won’t be overwritten unless the URL differs.
